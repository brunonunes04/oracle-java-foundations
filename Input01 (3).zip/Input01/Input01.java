import javax.swing.JOptionPane;

public class Input01 {
    public static void main(String[] args) {
        //Create a JOptionPane.
        //Store the input as a String and print it.
        String Input = JOptionPane.showInputDialog("Digite Algo: ");

        System.out.println("String digitada: " + Input);
        
        //Parse the input as an int.
        //Print its value +1
        String numeroTexto = "1";
        int numero = Integer.parseInt(numeroTexto + 1);
        System.out.println(numero);
        
        //Try creating a dialog, parsing it, and initializing an int in a single line.
        //You should have only one semicolon (;) in this line.
        int numeroDesafio = Integer.parseInt(JOptionPane.showInputDialog("Desafio: Digite outro número:"));
        
        System.out.println("Resultado do Desafio + 1: " + (numeroDesafio + 1));

        
    }
}
