public class Chickens01 {
    public static void main(String[] args) {
     int  eggsPerChicken = 8;
     int chickenCount = 4;
     int monday = (eggsPerChicken * chickenCount);
     int tuesChicken = chickenCount++;
     int tuesday = (tuesChicken * eggsPerChicken);
     int wedChicken = (chickenCount + tuesChicken) / 2;
     int wednesday = (wedChicken * eggsPerChicken);
     int totalEggs = monday + tuesday + wednesday;
     System.out.println(totalEggs);
    }   
}
