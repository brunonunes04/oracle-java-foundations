public class Chickens02 {
    public static void main(String[] args) {
     
        double mondayEggs = 100.0;
        double tuesdayEggs = 121.0;
        double wednesdayEggs = 117.0;
        double total = (mondayEggs + tuesdayEggs + wednesdayEggs);

        double dailyAverage = (total / 3);
        
        double monthlyAverage = (dailyAverage * 30);

        double eggProfit = 0.18;
        double monthlyProfit = (monthlyAverage * eggProfit);

        System.out.println("Daily Average:   " +dailyAverage);
        System.out.println("Monthly Average: " +monthlyAverage);
        System.out.println("Monthly Profit:  $" +monthlyProfit);
    }
    
}
