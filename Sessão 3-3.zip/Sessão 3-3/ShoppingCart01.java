import javafx.util.converter.BooleanStringConverter;

public class ShoppingCart01 {
    public static void main(String[] args) {
        // Declare and initialize String variables.  Do not initialize message yet.
        String custName = "Alex";
        String itemDesc = "Bolsa";
        String message = custName + " " + "quer comprar uma" + " " + itemDesc;
        
        // Print and run the code
        System.out.println(message);
    }
}
