public class ShoppingCart02 {
    public static void main(String[] args) {
        String custName = "Alex";
        String itemDesc = "Camisas";
        String message = custName+" quer comprar duas "+ itemDesc;
        
        // Declare and initialize numeric fields: price, tax, quantity.   
        double preco = 49.90;
        double taxa = 0.2;
        int quantidade = 2;
        
        
        // Declare and assign a calculated totalPrice
        double imposto = (preco * taxa);
        double precoTotal = (preco + imposto) * quantidade;
        
        // Modify message to include quantity 
        
        System.out.println(message);
        
        // Print another message with the total cost
        System.out.println("O custo total com imposto é: R$"+precoTotal);
    }    
}
